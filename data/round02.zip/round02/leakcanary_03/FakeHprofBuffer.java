package com.squareup.leakcanary;

import java.io.UnsupportedEncodingException;
import java.util.List;

public final class FakeHprofBuffer {
  private static final String PRE_O_CHARSET = "UTF-16BE";

  private final String stringCharset;

  private List<Byte> byteList;
  private List<byte[]> byteArrayList;

  private int[] intsToRead;
  private int intIndex = -1;
  private String[] stringsToRead;
  private int stringIndex = -1;

  public FakeHprofBuffer() {
    this(PRE_O_CHARSET);
  }

  public FakeHprofBuffer(String stringCharset) {
    this.stringCharset = stringCharset;
  }

  public void setIntsToRead(int... ints) {
    intsToRead = ints;
    intIndex = 0;
  }

  public void setStringsToRead(String... strings) {
    stringsToRead = strings;
    stringIndex = 0;
  }

  public void readSubSequence(byte[] bytes, int start, int length) {
    if (stringsToRead == null || stringIndex < 0 || stringIndex >= stringsToRead.length) {
      throw new UnsupportedOperationException("no bytes to read");
    }

    String s = stringsToRead[stringIndex++];
    try {
      System.arraycopy(s.getBytes(stringCharset), start, bytes, 0, length);
    } catch (UnsupportedEncodingException e) {
      throw new UnsupportedOperationException(e);
    }
  }

  public char readChar() {
    throw new UnsupportedOperationException("no bytes to read");
  }

  public int readInt() {
    if (intsToRead == null || intIndex < 0 || intIndex >= intsToRead.length) {
      throw new UnsupportedOperationException("no bytes to read");
    }
    return intsToRead[intIndex++];
  }

}
