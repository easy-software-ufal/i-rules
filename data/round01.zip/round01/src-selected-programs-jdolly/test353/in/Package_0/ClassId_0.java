package test353.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_1(){
    return this.fieldid_1;
  }
  protected int fieldid_1=-2;
}
