package test336.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_0(){
    return new ClassId_0().methodid_1(2);
  }
  public long methodid_1(  long param){
    if (fieldid_0 <= fieldid_1)     return fieldid_0 / fieldid_1;
    return fieldid_0;
  }
  public long methodid_0(  int param){
    if (fieldid_0 == fieldid_1)     return fieldid_0--;
    return param;
  }
  protected int fieldid_1=-1;
  private long fieldid_0=0;
}
