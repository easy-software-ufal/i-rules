package test511.in.Package_0;
public class ClassId_0 extends ClassId_1 {
  public long methodid_0(  long param){
    if (fieldid_0 < fieldid_1)     return fieldid_0 / fieldid_1;
    return param;
  }
  public long methodid_0(  int param){
    if (fieldid_0 <= fieldid_1)     return fieldid_0++;
    return fieldid_0;
  }
  private int fieldid_1=-2;
}
