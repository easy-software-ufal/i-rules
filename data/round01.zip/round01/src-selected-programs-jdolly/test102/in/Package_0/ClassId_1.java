package test102.in.Package_0;
public class ClassId_1 {
  public long methodid_0(  long param){
    return new ClassId_0().fieldid_1;
  }
  private int fieldid_1=0;
}
